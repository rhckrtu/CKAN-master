Dogecoin flag [courtesy of daviddwk](https://www.reddit.com/r/dogecoin/comments/1tdlgg/i_made_a_more_accurate_dogecoin_and_a_ksp_flag/).

Permission to distribute granted by:

> Feel free to use it as you wish. I'm not entirely sure how licensing works, but as long as you credit me somewhere I'd be happy.

Packaging and CKAN integration by [pjf](https://pjf.id.au/).
